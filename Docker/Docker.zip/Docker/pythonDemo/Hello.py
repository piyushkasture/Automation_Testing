# print("Hello")
# print("This is demo from Docker..")
# num1=input("Enter the first number: ")
# num2=input("Enter the second number: ")
num1=10
num2=665

if(num1>num2):
    print(f"{num1} is greater than {num2}")
else:
    print(f"{num2} is greater than {num1}")