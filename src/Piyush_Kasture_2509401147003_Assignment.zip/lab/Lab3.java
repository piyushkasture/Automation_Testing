package lab;

import java.util.Scanner;

public class Lab3 {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int sum=0;
		System.out.println("Enter number: ");
		int num = sc.nextInt();
		
		for(int i=0; i<=num;i++) {
			sum+=i;
		}
		System.out.println(sum);
	}

}
