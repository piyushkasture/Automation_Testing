package com.cdac.automation;



import io.appium.java_client.windows.WindowsDriver;

public class DesktopTesting {
	
	private WindowsDriver driver = null;
	
	@BeforeClass
	public static void setup
	
	
	
	
	
}
