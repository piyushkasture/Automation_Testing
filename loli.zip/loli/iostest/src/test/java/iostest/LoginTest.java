package iostest;



import org.openqa.selenium.*;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.*;
import org.testng.Assert;
import org.testng.annotations.*;

import java.net.URL;
import java.time.Duration;
import java.util.HashMap;

public class LoginTest {

    WebDriver driver;

    // IMPORTANT: Rotate your key if it was exposed earlier
    public static final String USERNAME = "piyush_UDu8F9";
    public static final String ACCESS_KEY = "V7rBU4zeThykRRNpACm3";
    public static final String BROWSERSTACK_URL =
            "https://" + USERNAME + ":" + ACCESS_KEY + "@hub-cloud.browserstack.com/wd/hub";

    WebDriverWait wait;

    public void markTestStatus(String status, String reason, WebDriver driver) {
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("browserstack_executor: {\"action\":\"setSessionStatus\", \"arguments\": {\"status\":\""
                + status + "\", \"reason\": \"" + reason + "\"}}");
    } // BrowserStack supports setSessionStatus executor. [web:57]

    @Parameters({"deviceName", "osVersion"})
    @BeforeMethod
    public void setUp(
            @Optional("iPhone 14 Pro Max") String deviceName,
            @Optional("16") String osVersion
    ) throws Exception {

        DesiredCapabilities caps = new DesiredCapabilities();

        // Mobile web on iOS => Safari (NO app capability)
        caps.setCapability("browserName", "Safari"); // iOS mobile web uses Safari. [web:124]

        HashMap<String, Object> bstackOptions = new HashMap<>();
        bstackOptions.put("deviceName", deviceName);
        bstackOptions.put("osVersion", osVersion);
        bstackOptions.put("realMobile", "true");
        bstackOptions.put("projectName", "My TestNG iOS Web Project");
        bstackOptions.put("buildName", "iOS Web Build 1.0");
        bstackOptions.put("sessionName", "SauceDemo on iOS Safari");

        caps.setCapability("bstack:options", bstackOptions); // BrowserStack capability format. [web:125]

        driver = new RemoteWebDriver(new URL(BROWSERSTACK_URL), caps);

        wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    @Test
    public void testSauceDemoOnIOSSafari() {
        try {
            driver.get("https://www.saucedemo.com");

            WebElement username = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("user-name")));
            WebElement password = driver.findElement(By.id("password"));
            WebElement loginButton = driver.findElement(By.id("login-button"));

            username.sendKeys("standard_user");
            password.sendKeys("secret_sauce");
            loginButton.click();

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".inventory_item")));

            markTestStatus("passed", "SauceDemo login ran on iOS Safari.", driver);
        } catch (Exception e) {
            markTestStatus("failed", "Test failed: " + e.getMessage(), driver);
            Assert.fail(e.getMessage());
        }
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown() {
        if (driver != null) driver.quit();
    }
}
