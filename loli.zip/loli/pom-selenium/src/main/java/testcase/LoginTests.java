package testcase;

import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import base.BaseTest;
import utils.CSVReader;
import utils.User;

public class LoginTests extends BaseTest {

    private LoginTestCase tc1;

    @BeforeClass
    public void setUpTest() {
        
        tc1 = new LoginTestCase(driver);
    }

    @Test
    public void validLoginTest() {
        tc1.validLogin();
        
    }

//    @Test
//    public void loginWithCSVDataTest() throws Exception {
//        List<User> users = CSVReader.getLoginUsers();
//        for (User usr : users) {
//            boolean isLogin = tc1.loginWithCredentials(usr.getUsername(), usr.getPassword());
//            Assert.assertTrue(isLogin,
//                    "Login failed for: " + usr.getUsername() + ", " + usr.getPassword());
//            tc1.logout();
//        }
//    }
}
