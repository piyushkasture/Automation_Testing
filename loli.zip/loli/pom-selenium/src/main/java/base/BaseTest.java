package base;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import drivermanager.DriverFactory;

public class BaseTest {

    protected static WebDriver driver;

    @BeforeSuite
//    @BeforeTest
    public void setUpSuite() {
        
        driver = DriverFactory.initDriver("chrome");
    }

//    @AfterTest
    @AfterSuite
//    @AfterTest
    public void tearDownSuite() throws InterruptedException {
        Thread.sleep(5000);          
        DriverFactory.quitDriver();  
    }
}
