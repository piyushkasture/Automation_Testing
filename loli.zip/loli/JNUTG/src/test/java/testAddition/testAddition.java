package testAddition;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import additionOfTwoNumber.Addition;

public class testAddition {
	Addition name= new Addition();
	
	@Test
	public void test1() {
		int result = name.AdditionNumber(20, 30);
		assertEquals(50, result);
	}
	@Test
	public void test2() {
		int result = name.SubtractNumber(30, 10);
		assertEquals(20, result);
	}
	@Disabled
	public void test3() {
		int result = name.SubtractNumber(20, 10);
		assertNotEquals(10225, result);
	}
	@Test
	public void test4() {
		int result = name.MultiplicationNumber(20, 10);
		assertEquals(200, result);
	}

}
