package testcal;

import org.junit.jupiter.api.Test;
import cal.Calculator;

import static org.junit.jupiter.api.Assertions.*;

class CalculatorTest {

    Calculator calc = new Calculator();

    // Addition Tests
    @Test
    void testAddEquals() {
        assertEquals(5, calc.add(2, 3));
    }

    @Test
    void testAddNotEquals() {
        assertNotEquals(6, calc.add(2, 3));
    }

    @Test
    void testAddResultNotNull() {
        Integer result = calc.add(2, 3);
        assertNotNull(result);
    }

    @Test
    void testAddResultIsNull() {
        Integer result = null;
        assertNull(result);
    }

    // Subtraction Tests
    @Test
    void testSubtractEquals() {
        assertEquals(1, calc.subtract(4, 3));
    }

    @Test
    void testSubtractNotEquals() {
        assertNotEquals(2, calc.subtract(4, 3));
    }

    @Test
    void testSubtractResultNotNull() {
        Integer result = calc.subtract(10, 5);
        assertNotNull(result);
    }

    // Multiplication Tests
    @Test
    void testMultiplyEquals() {
        assertEquals(12, calc.multiply(3, 4));
    }

    @Test
    void testMultiplyNotEquals() {
        assertNotEquals(10, calc.multiply(3, 4));
    }

    @Test
    void testMultiplyResultNotNull() {
        Integer result = calc.multiply(5, 2);
        assertNotNull(result);
    }

    // Division Tests
    @Test
    void testDivideEquals() {
        assertEquals(2, calc.divide(10, 5));
    }

    @Test
    void testDivideNotEquals() {
        assertNotEquals(3, calc.divide(10, 5));
    }

    @Test
    void testDivideResultNotNull() {
        Integer result = calc.divide(20, 4);
        assertNotNull(result);
    }

    
}