package additionOfTwoNumber;

public class Addition {
	public int AdditionNumber(int num1, int num2) {
		return num1+num2;
	}
	public int SubtractNumber(int num1, int num2) {
		return num1-num2;
	}
	public int MultiplicationNumber(int num1, int num2) {
		return num1*num2;
	}
}
