package test;

import java.lang.reflect.Method;

public class ReflectionTest {
	private int no1;
	public int no2;
	
	
	public int getNo1() {
		return no1;
	}


	public void setNo1(int no1) {
		this.no1 = no1;
	}


	public int getNo2() {
		return no2;
	}


	public void setNo2(int no2) {
		this.no2 = no2;
	}


	public static void main(String[] args) throws InstantiationException, IllegalAccessException {
		
		Method []methods = ReflectionTest.class.getMethods();
		ReflectionTest obj = ReflectionTest.class.newInstance();
		for(Method m : methods) {
			System.out.println(m.getName()+"-"+ m.getModifiers()+"-"+m.getParameterCount());
		}
		
	}

}
