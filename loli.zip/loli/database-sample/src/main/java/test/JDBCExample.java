package test;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCExample {
	private static final String URL = "jdbc:mysql://localhost:3306/na";
	private static final String USER = "root";
	private static final String PASSWORD = "";

	public static Connection getConnection() throws SQLException {
		return DriverManager.getConnection(URL, USER, PASSWORD);
	}


	public static void insertEmployee(String first, String last, String email, String phone,
			Date hireDate, double salary) {
		String sql = "INSERT INTO employees (first_name, last_name, email, phone, hire_date, salary) VALUES (?, ?, ?, ?, ?, ?)";
		try (Connection conn = getConnection();
				PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setString(1, first);
			ps.setString(2, last);
			ps.setString(3, email);
			ps.setString(4, phone);
			ps.setDate(5, hireDate);
			ps.setDouble(6, salary);
			ps.executeUpdate();
			System.out.println("Employee inserted successfully!");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}



	public static void getAllEmployees() {
	    String sql = "SELECT * FROM employees";
	    try (Connection conn = getConnection();
	         Statement stmt = conn.createStatement();
	         ResultSet rs = stmt.executeQuery(sql)) {
	        while (rs.next()) {
	            System.out.println(rs.getInt("emp_id") + " - " + rs.getString("first_name") +
	                               " " + rs.getString("last_name") + " - " + rs.getString("email") +  " - " + rs.getDouble("salary") +    " - " + rs.getDate("hire_date") +    " - " + rs.getString("phone"));
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	
	public static void updateEmployeeSalary( int empId , String newPhone) {
	    String sql = "UPDATE employees SET phone = ? WHERE emp_id = ?";
	    try (Connection conn = getConnection();
	         PreparedStatement ps = conn.prepareStatement(sql)) {
//	        ps.setDouble(1, newSalary);
	        ps.setInt(2, empId);
	        ps.setString(1, newPhone);
	        int affectedRows = ps.executeUpdate();
	        System.out.println("Employee salary updated affected rows:"+affectedRows);
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	
	public static void deleteEmployee(int empId) {
	    String sql = "DELETE FROM employees WHERE emp_id = ?";
	    try (Connection conn = getConnection();
	         PreparedStatement ps = conn.prepareStatement(sql)) {
	        ps.setInt(1, empId);
	        ps.executeUpdate();
	        System.out.println("Employee deleted!");
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	
	public static void main(String[] args) {
//	    insertEmployee("piyush", "temp", "sdk@gmail.com", "1234567890",
//	                   Date.valueOf("2024-01-01"), 60000.00);

	    getAllEmployees();
//
	    updateEmployeeSalary(1, "111111111");
//
//	    deleteEmployee(2);
	}


}
