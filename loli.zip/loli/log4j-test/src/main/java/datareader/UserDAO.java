package datareader;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {
    public static List<User> getAllUsers() throws Exception {
        List<User> users = new ArrayList<>();

        // Adjust DB URL, username, password as per your setup
        Connection conn = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/espocrm", "root", "password");

        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT username, password FROM login");

        while (rs.next()) {
            users.add(new User(rs.getString("username"), rs.getString("password")));
        }

        rs.close();
        stmt.close();
        conn.close();
        return users;
    }
}