package datareader;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.List;

public class LoginTest {
    private WebDriver driver;

    @DataProvider(name = "loginData")
    public Object[][] loginData() throws Exception {
        List<User> users = UserDAO.getAllUsers();
        Object[][] data = new Object[users.size()][1];
        for (int i = 0; i < users.size(); i++) {
            data[i][0] = users.get(i);
        }
        return data;
    }

    @Test(dataProvider = "loginData")
    public void testLogin(User user) {
        driver = new ChromeDriver();
        driver.get("http://localhost/espocrm/login"); // adjust URL

        LoginPage loginPage = new LoginPage(driver);
        loginPage.login(user.getUsername(), user.getPassword());

        // Add assertions here, e.g. check if dashboard loads
        // Assert.assertTrue(driver.getTitle().contains("Dashboard"));

        driver.quit();
    }
}