package Assignments;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class A1 {

    public static void main(String[] args) throws InterruptedException {
        
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.google.com/");
        Thread.sleep(Duration.ofSeconds(7));
        
        By cr = By.id("ZnpjSd");  
        
        if (checkElementExists(driver, cr)) {
            driver.findElement(cr).click();  
            System.out.println("Element clicked!");
        } else {
            System.out.println("Element not found!");
        }
        
        driver.quit();
    }
    
    public static boolean checkElementExists(WebDriver driver, By locator) {
        return !driver.findElements(locator).isEmpty();
    }
}