package Assignments;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class A5_Wsleep {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		// Explicit wait
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		
		driver.get("http://localhost/espocrm");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		WebElement uname = driver.findElement(By.xpath("//input[@id='field-userName']"));
		uname.sendKeys("admin");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

		
		WebElement upass = driver.findElement(By.xpath("//input[@id='field-password']"));
		upass.sendKeys("admi");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

		
		WebElement lbtn = driver.findElement(By.xpath("//button[@id='btn-login']"));
		lbtn.click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		

//		// Verify login success by checking presence of dashboard element
//        WebElement dashboard = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[@class='not-in-more tab active']//a[@class='nav-link']")));
//
//        if (dashboard.isDisplayed()) {
//            System.out.println("Login successful ");
//        } else {
//            System.out.println("Login failed ");
//        }
		
//		WebElement dashboard = driver.findElement(By.xpath("//li[@class='not-in-more tab active']//a[@class='nav-link']"));
//
//        if (dashboard.isDisplayed()) {
//            System.out.println("Login successful ");
//        } else {
//            System.out.println("Login failed ");
//        }
        
//     // Success element check
//        boolean success = driver.findElements(By.xpath("//li[@class='not-in-more tab active']//a[@class='nav-link']")).size() > 0;
//
//        // Failure element check
//        boolean failure = driver.findElements(By.xpath("//div[@class='message']")).size() > 0;
//
//        // Simple if–else
//        if (success) {
//            System.out.println("Login successful ");
//        } else {
//            System.out.println("Login failed ");
//        }
		// Success element
        WebElement dashboard = driver.findElement(By.xpath("//li[@class='not-in-more tab active']//a[@class='nav-link']"));
        // Failure element
        WebElement errorMsg = driver.findElement(By.xpath("//div[@class='message']"));

        // Simple if–else
        if (dashboard.isDisplayed()) {
            System.out.println("Login successful ");
        } else {
            System.out.println("Login failed ");
        }








		


	}

}
