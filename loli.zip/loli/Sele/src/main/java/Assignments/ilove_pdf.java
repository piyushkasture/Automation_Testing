package Assignments;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ilove_pdf {

	public static void main(String[] args) {
		
		ChromeDriver driver =new ChromeDriver();
		
		driver.get("https://www.ilovepdf.com/pdf_to_excel");
		
		
		WebElement w = driver.findElement(By.xpath("//input[@type='file']"));
		w.sendKeys("C:\\Users\\cdac\\Documents\\aptitude.pdf");
		
		
		

	}

}
