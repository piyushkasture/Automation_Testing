package Assignments;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Flipkart {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriver driver = new ChromeDriver();
		
		
		driver.get("https://www.flipkart.com/");
		Thread.sleep(Duration.ofSeconds(5));
		
		Actions actions = new Actions(driver);
//		WebElement ele = driver.findElement(By.xpath("//span[text()='Electronics']"));
	
		WebElement ele = driver.findElement(By.cssSelector("div[aria-label=\"Electronics\"] .YBLJE4"));
		actions.moveToElement(ele).pause(Duration.ofSeconds(3)).perform();
		Thread.sleep(Duration.ofSeconds(3));

		
//		WebElement soundbars = driver.findElement(By.xpath("//a[text()='Soundbars']"));
//		WebElement soundbars = driver.findElement(By.xpath("//a[text()='Soundbars']"));
//		actions.moveToElement(soundbars).click().perform();
		WebElement soundbars = driver.findElement(By.cssSelector("a._1BJVlg._11MZbx"));
		actions.moveToElement(soundbars).pause(Duration.ofSeconds(3)).perform();
		
		WebElement soundb = driver.findElement(By.cssSelector("div.uAl2uE +a +a +a +a +a +a"));
		actions.moveToElement(soundb).pause(Duration.ofSeconds(3)).perform();
		
		actions.scrollToElement(driver.findElement(By.cssSelector("a._9QVEpD")));
		actions.perform();
		
		
		

	}

}
