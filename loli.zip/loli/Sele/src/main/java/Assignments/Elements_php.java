package Assignments;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Elements_php {

	public static void main(String[] args) throws InterruptedException {
		
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://localhost/sample/elements.php");
		
		Thread.sleep(Duration.ofSeconds(5));
		
		WebElement username = driver.findElement(By.id("username"));
		username.sendKeys("admin");
		
		Thread.sleep(Duration.ofSeconds(1));
		
		WebElement password = driver.findElement(By.id("password"));
		password.sendKeys("admin");
		
		Thread.sleep(Duration.ofSeconds(1));
		
		WebElement rdio = driver.findElement(By.id("male"));
		rdio.click();
		Thread.sleep(Duration.ofSeconds(1));
		
		
		WebElement check = driver.findElement(By.id("music"));
		check.click();
		
		Thread.sleep(Duration.ofSeconds(2));
		
		WebElement opn = driver.findElement(By.id("country"));
		Select option = new Select(opn);
		
		option.selectByVisibleText("India");
		
		Thread.sleep(Duration.ofSeconds(2));
		
		
		WebElement skill = driver.findElement(By.id("skills"));
		Select skills = new Select(skill);
		
		skills.selectByVisibleText("Java");
		skills.selectByVisibleText("Python");
		
		WebElement com = driver.findElement(By.id("comments"));	
		com.sendKeys("heloo piyush");
		
		WebElement f = driver.findElement(By.id("fileUpload"));
		f.sendKeys("C:\\Users\\cdac\\Documents\\AssignmentBug.csv");
		
		WebElement date = driver.findElement(By.id("dob"));
		date.sendKeys("23-07-2003");
		
		
		
		
	

		
		

	}

}
