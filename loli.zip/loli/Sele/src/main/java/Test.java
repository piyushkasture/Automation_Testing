import java.time.Duration;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.logging.LogEntries;

public class Test {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver = new ChromeDriver();
		driver.get("http://localhost/espocrm/#");
		
		Thread.sleep(Duration.ofSeconds(5));
		
		String title =driver.getTitle();
		System.out.println(title);
		
		String a = driver.getPageSource();
		System.out.println(a);
		
		String cu = driver.getCurrentUrl();
		System.out.println(cu);
		
		driver.navigate().to("https://www.nplindia.in/clockcode/html/");
		
//		Thread.sleep(Duration.ofSeconds(5));
//		
//		driver.navigate().to("https://www.youtube.com/watch?v=Nq2wYlWFucg");
//		
//		Thread.sleep(Duration.ofSeconds(5));
//		
//		driver.navigate().back();
//		
//		Thread.sleep(Duration.ofSeconds(5));
//
//		driver.navigate().forward();
//		
//		Thread.sleep(Duration.ofSeconds(5));
//
//		driver.navigate().refresh();
//		 
        //Window
//		driver.manage().window().fullscreen();
//		
//		Thread.sleep(Duration.ofSeconds(5));
//		
//		driver.manage().window().minimize();
//		Dimension minsize = driver.manage().window().getSize();		
//		System.out.println(minsize);
//		
//		driver.manage().window().maximize();
//		Dimension mxsize = driver.manage().window().getSize();		
//		System.out.println(mxsize);
//		
//		Point posi = driver.manage().window().getPosition();
//		System.out.println(posi);
//		
//		driver.manage().window().setSize(new Dimension(500, 700));
//		
//		Dimension nsize = driver.manage().window().getSize();
//		System.out.println(nsize);
//		
//		driver.manage().window().setPosition(new Point(80, 80));
//		
//		
		System.out.println(driver.manage().logs().getAvailableLogTypes());
		
		LogEntries log = driver.manage().logs().get("Browser");
		System.out.println(log);
		
		
	}

}
