import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Google {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.google.com/");
		
		Thread.sleep(Duration.ofSeconds(7));
		
//		WebElement chk = driver.findElement(By.className("CgwTDb"));
//		System.out.println(chk.isDisplayed());
		boolean result;
        try {
            WebElement chk = driver.findElement(By.className("CgwTDb"));
            result = chk.isDisplayed();
        } catch (Exception e) {
            result = false; // element not found
        }

        System.out.println(result);
		
		
		

	}

}
