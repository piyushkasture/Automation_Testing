import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Form {

	public static void main(String[] args) throws InterruptedException {

		WebDriver driver = new ChromeDriver();
		driver.get("http://localhost/espocrm");
		Thread.sleep(Duration.ofSeconds(2));
		driver.findElement(By.xpath("//input[@id='field-userName']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@id='field-password']")).sendKeys("admin");
		
		driver.findElement(By.xpath("//button[@id='btn-login']")).click();
		
		Thread.sleep(Duration.ofSeconds(2));
		
		driver.get("http://localhost/espocrm/#Account");
		Thread.sleep(Duration.ofSeconds(5));
		
		driver.findElement(By.xpath("//a[@title='Piyush']")).click();
		
		Thread.sleep(Duration.ofSeconds(5));
		
		WebElement nm = driver.findElement(By.xpath("//span[text()='Name']/parent::label/following-sibling::div/span"));
		System.out.println(nm.getText());
		
		
		WebElement email = driver.findElement(By.xpath("//span[normalize-space()='test@test.com']"));
		System.out.println(email.getText());
		
		WebElement web =driver.findElement(By.xpath("//a[normalize-space()='temp.com']"));
		System.out.println(web.getText());
		
		WebElement addd =driver.findElement(By.xpath("//div[@data-name='billingAddress']/div[1]"));
		System.out.println(addd.getText());
		
		
		
		
		
	}

}
