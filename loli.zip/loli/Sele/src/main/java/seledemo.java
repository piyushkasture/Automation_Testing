import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class seledemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		WebDriver dd = new ChromeDriver();
		//dd.get("https://www.youtube.com/");
		
		dd.navigate().to("https://openweathermap.org/");
		
		WebElement text =dd.findElement(By.xpath("//span[@class='heading']"));
		
				System.out.print(text.getText());
				WebElement input =	dd.findElement(By.xpath("//input[@placeholder='Search city']"));
				input.sendKeys("Today");
		
	}

}
