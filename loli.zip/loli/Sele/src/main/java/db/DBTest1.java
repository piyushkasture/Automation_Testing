package db;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class DBTest1 {

	@Test
	public void m1() {
		System.out.println("DBTest1 Method m1");
	}
	
	@Test
	public void m2() {
		System.out.println("DBTest1 Method m2");
	}
	
	@BeforeSuite
	public void bs1() {
		System.out.println("DBTest1 BS1");
	}
	
}
