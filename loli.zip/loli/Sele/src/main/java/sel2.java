import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class sel2 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("http://localhost/espocrm");
		
		Thread.sleep(Duration.ofSeconds(5) );
		
		
		Cookie coki1 = new Cookie("mod1", "selenium");
		driver.manage().addCookie(coki1);
		
		Cookie coki2 = new Cookie("mod", "database");
		driver.manage().addCookie(coki2);
		
		Cookie neecoki = driver.manage().getCookieNamed("mod1");
		System.out.println(coki1);
		
		Set<Cookie>  cookies = driver.manage().getCookies();
		System.out.println("alll cookiesss");
		for (Cookie cookie : cookies) {
			System.out.println(cookie);
		}
		
		System.out.println("del cookie mod1");
		driver.manage().deleteCookie(coki1);
		
		cookies = driver.manage().getCookies();
		System.out.println("after deleting mod1");
		for ( Cookie cookie : cookies) {
			System.out.println(cookie);
		}
		
		driver.manage().deleteAllCookies();
		System.out.println("deleted all coookies");
		
		cookies = driver.manage().getCookies();
		System.out.println("after deleting all");
		for ( Cookie cookie : cookies) {
			System.out.println(cookie);
		}
		
		
		//driver.quit();

	}

}
