package com.cdac.automation;

package io.appium.java_client.windows.WindowsDriver;

public class DesktopTesting {
	
	private WindowsDriver driver = null;
}
