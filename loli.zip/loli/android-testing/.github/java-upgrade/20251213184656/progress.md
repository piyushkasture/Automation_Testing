# Upgrade Progress

  ### ❗ Generate Upgrade Plan
  - [[View Log]](logs\1.generatePlan.log)
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  #### Errors
  - Failed to get git status for c:\Users\lenovo\OneDrive\Documents\Projects\AndroidAutomation: 'git' is not recognized as an internal or external command, operable program or batch file.
  </details>