package com.automation;

import java.net.MalformedURLException;
import java.net.URL;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import javax.imageio.ImageIO;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.*;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

import org.openqa.selenium.OutputType;

public class BouncingBallTest {

    private static AndroidDriver driver;

    @BeforeClass
    public static void setUp() throws MalformedURLException {
        UiAutomator2Options options = new UiAutomator2Options()
                .setPlatformName("Android")
                .setDeviceName("Pixel_5")
                .setApp("C:\\Users\\cdac\\Downloads\\ApiDemos-debug.apk")
                .setAppPackage("io.appium.android.apis")
                .setAppActivity("io.appium.android.apis.ApiDemos")
                .setAutomationName("UiAutomator2");

        driver = new AndroidDriver(new URL("http://127.0.0.1:4723/"), options);
        assertNotNull("Driver not created", driver);
        System.out.println("Driver started");
    }

    private static Color getPixelColor(int x, int y) throws Exception {
        byte[] png = driver.getScreenshotAs(OutputType.BYTES); // screenshot [web:145]
        BufferedImage img = ImageIO.read(new ByteArrayInputStream(png));
        int argb = img.getRGB(x, y); // pixel ARGB int [web:186]
        return new Color(argb, true);
    }

    private static String toHex(Color c) {
        return String.format("#%02X%02X%02X", c.getRed(), c.getGreen(), c.getBlue());
    }

    @Test
    public void checkColorChangeAfter5Seconds() throws Exception {
        driver.findElement(AppiumBy.accessibilityId("Animation")).click();
        driver.findElement(AppiumBy.accessibilityId("Bouncing Balls")).click();
        System.out.println("Opened Bouncing Balls screen");

        // Choose a pixel point (change x,y if needed)
        int x = 300, y = 500;

        Color c1 = getPixelColor(x, y);
        System.out.println("T0  Pixel(" + x + "," + y + ") RGB="
                + c1.getRed() + "," + c1.getGreen() + "," + c1.getBlue()
                + " HEX=" + toHex(c1));

        Thread.sleep(5000); // wait 5 seconds

        Color c2 = getPixelColor(x, y);
        System.out.println("T5s Pixel(" + x + "," + y + ") RGB="
                + c2.getRed() + "," + c2.getGreen() + "," + c2.getBlue()
                + " HEX=" + toHex(c2));

        assertNotEquals("Color did NOT change after 5 seconds at chosen pixel!",
                c1.getRGB(), c2.getRGB());

        System.out.println("PASS: Color changed after 5 seconds");
    }

    @AfterClass
    public static void tearDown() {
        if (driver != null) {
            driver.quit();
            System.out.println("Driver quit");
        }
    }
}
