package com.automation;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AppiumTest {

    private static AndroidDriver driver;

    @BeforeClass
    public static void setUp() throws MalformedURLException {
        // Define capabilities using UiAutomator2Options (new in Java Client 10)
        UiAutomator2Options options = new UiAutomator2Options()
                .setPlatformName("Android")
                .setDeviceName("Pixel_5") // emulator or device name
                .setApp("C:\\Users\\cdac\\Downloads\\ApiDemos-debug.apk")
                .setAppPackage("io.appium.android.apis")
                .setAppActivity("io.appium.android.apis.ApiDemos")
                .setAutomationName("UiAutomator2");

        // Initialize driver
        driver = new AndroidDriver(new URL("http://127.0.0.1:4723/"), options);
    }

//    @Test
//    public void sampleTest() {
//        driver.findElement(AppiumBy.accessibilityId("Views")).click();
//    }
    
//    @Test //maintext pass
//    public void handleAlertsTest() {
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//
//        // Navigate to App -> Alert Dialogs
//        driver.findElement(AppiumBy.accessibilityId("App")).click();
//        driver.findElement(AppiumBy.accessibilityId("Alert Dialogs")).click();
//
//        // Text entry dialog
//        
//    }
    @Test //pass
    public void handleAlertsTest() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // Navigate to Alert Dialogs
        driver.findElement(AppiumBy.accessibilityId("App")).click();
        driver.findElement(AppiumBy.accessibilityId("Alert Dialogs")).click();

        // OK Cancel dialog pass  1.
        driver.findElement(AppiumBy.accessibilityId("OK Cancel dialog with a message")).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.id("android:id/button1"))).click(); // OK
//
        
        // pass 2
        wait.until(ExpectedConditions
                .elementToBeClickable(AppiumBy.accessibilityId("OK Cancel dialog with Holo Light theme")))
            .click();

        // Wait until the OK button is clickable and click it
        wait.until(ExpectedConditions
                .elementToBeClickable(By.id("android:id/button1")))
            .click();

        //pass 3
        driver.findElement(AppiumBy.accessibilityId("OK Cancel dialog with traditional theme")).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.id("android:id/button1"))).click();
        
        
        //pass 4
        driver.findElement(AppiumBy.androidUIAutomator(
              "new UiSelector().resourceId(\"io.appium.android.apis:id/text_entry_button\")")).click();
  //
//          // Wait for username field
          WebElement username = wait.until(ExpectedConditions.visibilityOfElementLocated(
              AppiumBy.androidUIAutomator("new UiSelector().resourceId(\"io.appium.android.apis:id/username_edit\")")));
          username.sendKeys("demoUser");
  
          WebElement password = wait.until(ExpectedConditions.visibilityOfElementLocated(
              AppiumBy.androidUIAutomator("new UiSelector().resourceId(\"io.appium.android.apis:id/password_edit\")")));
          password.sendKeys("demoPass");
  
          // Click OK
          driver.findElement(By.id("android:id/button1")).click();
          
          
       // pass 5
          wait.until(ExpectedConditions
                  .elementToBeClickable(AppiumBy.accessibilityId("OK Cancel dialog with ultra long message")))
              .click();

          // Wait until the OK button is clickable and click it
          wait.until(ExpectedConditions
                  .elementToBeClickable(By.id("android:id/button1")))
              .click();

         

    }
    



    // @Test
    // public void helloWorldTest() throws InterruptedException {
    //     // Print device time as a "Hello World" action
    //     System.out.println("Hello World! Device time is: " + driver.getDeviceTime());
    //     // driver.findElement(By.id("Views")).click();
    //     driver.findElement(AppiumBy.accessibilityId("Views")).click();
    //     Thread.sleep(2000);
    //     // final var finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
    //     // var tapPoint = new Point(219, 2264);
    //     // var tap = new Sequence(finger, 1);
    //     // tap.addAction(finger.createPointerMove(Duration.ofMillis(0),
    //     //     PointerInput.Origin.viewport(), tapPoint.x, tapPoint.y));
    //     // tap.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
    //     // tap.addAction(new Pause(finger, Duration.ofMillis(50)));
    //     // tap.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
    //     // driver.perform(Arrays.asList(tap));
    //     final var finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
    //     var start = new Point(622, 2106);
    //     var end = new Point (648, 1280);
    //     var swipe = new Sequence(finger, 1);
    //     swipe.addAction(finger.createPointerMove(Duration.ofMillis(0),
    //         PointerInput.Origin.viewport(), start.getX(), start.getY()));
    //     swipe.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
    //     swipe.addAction(finger.createPointerMove(Duration.ofMillis(1000),
    //         PointerInput.Origin.viewport(), end.getX(), end.getY()));
    //     swipe.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
    //     driver.perform(Arrays.asList(swipe));
    //     // Example: click on "Accessibility" menu in ApiDemos
    //     // WebElement accessibility = driver.findElementByAccessibilityId("Accessibility");
    //     // accessibility.click();
    // }

//    @AfterClass
//    public static void tearDown() {
//        if (driver != null) {
//            driver.quit();
//        }
//    }
}
