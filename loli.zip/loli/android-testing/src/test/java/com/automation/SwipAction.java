package com.automation;

//import java.awt.Point;

import java.net.MalformedURLException;
import java.net.URL;

import org.junit.BeforeClass;
import org.junit.Test;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

import org.openqa.selenium.Point;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;

import java.time.Duration;
import java.util.Arrays;
import java.util.Collections;

public class SwipAction {

    private static AndroidDriver driver;

    @BeforeClass
    public static void setup() throws MalformedURLException {
        UiAutomator2Options options = new UiAutomator2Options();
        options.setPlatformName("Android");
        options.setDeviceName("Pixel_5");
        options.setApp("C:\\Users\\cdac\\Downloads\\ApiDemos-debug.apk");
        options.setAppPackage("io.appium.android.apis");
        options.setAppActivity(".ApiDemos"); // specify main activity

        driver = new AndroidDriver(new URL("http://127.0.0.1:4723/"), options);
    }

    @Test
    public void checkSwipe() {
////    	System.out.println("Swipe performed successfully!");
////    	driver.findElement(AppiumBy.accessibilityId("App")).click();
    	driver.findElement(AppiumBy.accessibilityId("Views")).click();
    	PointerInput fing= new PointerInput(PointerInput.Kind.TOUCH, "fingure");
    	Point starPoint = new Point(622,2106);
	    Point enPoint = new Point(622,1280);
    	
    	Sequence seq = new Sequence(fing, 0);
    	
//    	 Move finger to start position
      seq.addAction(fing.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), starPoint.getX(), starPoint.getY()));
      // Finger touches down
      seq.addAction(fing.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
      // Finger moves to end position
      seq.addAction(fing.createPointerMove(Duration.ofMillis(2000), PointerInput.Origin.viewport(), enPoint.getX(), enPoint.getY()));
      // Finger lifts up
      seq.addAction(fing.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
      
   	    driver.perform(Arrays.asList(seq));
//   	    driver.perform(Collections.singletonList(seq));
      
  }
//    @Test
//    public void checkSwipe() {
//        driver.findElement(AppiumBy.accessibilityId("Views")).click();
//
//        PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
//        
//        
//        Sequence swipe = new Sequence(finger, 1);
//
//        // Move finger to start position
//        swipe.addAction(finger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), 622, 2106));
//        // Finger touches down
//        swipe.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
//        // Finger moves to end position
//        swipe.addAction(finger.createPointerMove(Duration.ofMillis(1000), PointerInput.Origin.viewport(), 622, 1280));
//        // Finger lifts up
//        swipe.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
//
//        driver.perform(Collections.singletonList(swipe));
//    }
}