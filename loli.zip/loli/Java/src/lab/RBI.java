package lab;

public interface RBI {
	
	public abstract void calculateEMI();
	
	public static void linkwithAadhar() {
		
		System.out.println("link your mobile number with aadhar");
	}
	
}
