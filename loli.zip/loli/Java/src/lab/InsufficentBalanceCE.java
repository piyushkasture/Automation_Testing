package lab;

public class InsufficentBalanceCE extends Exception{

	public InsufficentBalanceCE() {
		super("Insufficent Balance");
	}
	

}
