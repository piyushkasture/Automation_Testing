package lab;

public class NegativeAmount extends Exception{

	public NegativeAmount() {
		super("You enter negative amount");
	}
	
}
