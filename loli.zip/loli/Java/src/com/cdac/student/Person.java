package com.cdac.student;

public class Person {
	String name;
	int age;
	String city;
	
	public Person(String name, int age, String city) {
		this.name = name;
		this.age = age;
		this.city = city;
	}

	public Person(String name) {
		super();
		this.name = name;
	}


	
	
	
}
