package com.cdac;

public class Array2D1 {
	public static void main(String[] args) {
		
		
	}

}
