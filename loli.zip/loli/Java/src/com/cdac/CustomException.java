package com.cdac;

public class CustomException extends Throwable {
	public CustomException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
