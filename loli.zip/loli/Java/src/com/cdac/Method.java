package com.cdac;

public class Method {

}
