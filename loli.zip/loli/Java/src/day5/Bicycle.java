package day5;

public class Bicycle implements Vehicle {

	@Override
	public void startEngine() {
		System.out.println("Bicycle started");
		// TODO Auto-generated method stub
		
	}

	@Override
	public void stopEngine() {
		System.out.println("Bicycle stop");
		// TODO Auto-generated method stub
		
	}

	@Override
	public void turn(String direction) {
		System.out.println("Bicycle direction West");
		// TODO Auto-generated method stub
		
	}

}
