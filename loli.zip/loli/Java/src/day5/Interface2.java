package day5;

public interface Interface2 extends Interface1 {
	public void name() ;
	@Override
	default void namjje() {
		// TODO Auto-generated method stub
		
	}
	
	
}
