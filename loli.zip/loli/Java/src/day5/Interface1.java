package day5;

public interface Interface1 {
	
	public abstract void namjje();

}
