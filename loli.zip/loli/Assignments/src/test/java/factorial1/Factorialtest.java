package factorial1;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import factorial.Factorial;


public class Factorialtest {
	Factorial obj = new Factorial();
	@Test
	public void testfact1()
	{
	long actual_result = obj.factorial(5);
    assertEquals(120,actual_result,()-> "Expected result is correct");
	}

//	@Test
//	public void testfact2()
//	{
//	long actual_result = obj.factorial(1);
//    assertNotEquals(1,actual_result,()-> "Expected result is not correct");
//	}
	
	@Test
	public void testfact3() {
		double actual_result = obj.factorial(15);
		assertNotEquals(125774, actual_result);
	}
	
	@Test
	public void testfact4() {
		double actual_result = obj.factorial(15);
		assertNotNull(4);
	}
//	
	@Test
	public void testfact5() {
		assertTrue(obj.factorial(5)==120);
	}
	
	@Test
	public void testfact6() {
		long actual_result = obj.factorial(2424);
		assertNotEquals(125774, actual_result);
	}
	
	@Test
	public void testfact7() {
		long actual_result = obj.factorial(0);
		assertNotEquals(0, actual_result,()-> "Expected output not match");
	}
	
	@Test
	public void testfact8() {
		long actual_result = obj.factorial(5);
		assertNotEquals(125774, actual_result);
	}
	
	
}
