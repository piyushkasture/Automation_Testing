package numbertest;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import number.EvenOdd;

public class NumberCheckTest {
	
	EvenOdd obj = new EvenOdd();
	
	@Test
	public void test1() {
		boolean result = obj.EvenOddNumber(4);
		assertEquals(true, result,  "The number is Even");
		
	}
	@Test
	public void test2() {
		boolean result = obj.EvenOddNumber(8);
		assertEquals(true, result,  "The number is Even");
		
	}
	@Test
	public void test3() {
		boolean result = obj.EvenOddNumber(10001);
		assertNotEquals(true, result,  "The number is Even");
		
	}
	@Test
	public void test4() {
		boolean result = obj.EvenOddNumber(3);
		assertEquals(false, result,  "The number is Odd");
		
	}
	@Test
	public void test5() {
		boolean result = obj.EvenOddNumber(30);
		assertNotEquals(false, result, "The number is Odd");
		
	}
	
	@Test
	public void test6() {
	    boolean result = obj.EvenOddNumber(126);
	    assertTrue(result, "The number is Odd");
	}
	@Test
	public void test7() {
	    boolean result = obj.EvenOddNumber(137);
	    assertFalse(result, "The number is Odd");
	}
	
	@ParameterizedTest
	@ValueSource(ints = {2, 4, 6, 8, 10})
	void testEvenNumbers(int number) {
	    assertTrue(obj.EvenOddNumber(number), number + "the number is even");
	}
	
	@ParameterizedTest
	@ValueSource(ints = {3, 5, 7, 9, 11})
	void testOddNumbers(int number) {
	    assertFalse(obj.EvenOddNumber(number), number + "the number is Odd");
	}
	
	@ParameterizedTest
	@ValueSource(ints = {2, 4, 6, 8, 10, 3, 5, 7, 9, 101})
	void testEvenOddNumbers(int number) {
	    boolean isEven = number % 2 == 0;
	    assertEquals(isEven, obj.EvenOddNumber(number), number + " test failed");
	}
	
	@ParameterizedTest
	@ValueSource(ints = {2, 4, 6, 8, 10, 3, 5, 7, 9, 33})
	void testEvenOddNumberss(int number) {
	    boolean result = obj.EvenOddNumber(number);
	    
	    assertAll(
	            () -> assertNotNull(result, "Result should not be null"),
	            () -> assertTrue(result || !result, "Result should be boolean"),
	            () -> assertEquals(number % 2 == 0, result, number + " test failed")
	        );

	}
	
	@ParameterizedTest
	@ValueSource(ints = {2, 4, 6, 8, 10, 3, 5, 7, 9})
	void testEvenOddNumbersss(int num) {
	    boolean result = obj.EvenOddNumber(num);

	    assertAll(
	        () -> {
	            if (num % 2 == 0) {
	                assertTrue(result == true, num + " should be even");
	            } else {
	                assertTrue(result == false, num + " should be odd");
	            }
	        }
	    );
	}


}