package HelloWorld;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Test;

import helloWorld.HelloWorld;

public class GreetingTest {
	
	HelloWorld obj = new HelloWorld();
	
	@Test
	public void test1() {
		String result = obj.sayHello("World");
		assertEquals("Hello, World!", result);
	}
	
	@Test
	public void test2() {
		String result = obj.sayHello("Ccst");
		assertEquals("Hello, Ccst!", result);
	}
	
	@Test
	public void test3() {
		String result = obj.sayHello("Ccst");
		assertNotEquals("Hello, World!", result);
	}

}