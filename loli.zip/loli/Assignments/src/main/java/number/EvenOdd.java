package number;

public class EvenOdd {
	public boolean EvenOddNumber(int num) {
		if(num%2==0) {
			return true;
		}
		else {
			return false;
		}
		
		
	}


}
