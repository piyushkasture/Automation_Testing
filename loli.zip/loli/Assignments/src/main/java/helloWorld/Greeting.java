package helloWorld;

public class Greeting {
	
	public String sayHello(String name) {
        return "Hello," + " " + name +"!";
    }

}
