package hooks;

import io.cucumber.java.*;

public class Hooks {
	
	@Before
	public void beforeTest() {
		System.out.println("Before test");
	}
	
	@BeforeAll
	public static void beforeTAll() {
		System.out.println("Before All");
	}

}
