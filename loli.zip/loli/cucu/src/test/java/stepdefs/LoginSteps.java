package stepdefs;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginSteps {

    @Given("I am on the login page")
    public void login() {
        System.out.println("Navigated to login page");
    }

    @When("I enter username {string}")
    public void usernamePassword(String username) {
        System.out.println("Successfully entered username: " + username);
//        System.out.println("Successfully entered password: " + password);
    }
//
//    @And("I click on {string} button")
//    public void clickBtn(String button) {
//        System.out.println("Clicked on button: " + button);
//    }

    
}