package web;

import java.net.MalformedURLException;
import java.net.URL;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

public class ChromeTest {

    public static AndroidDriver driver;

    @BeforeTest
    public void setup() throws MalformedURLException {
        UiAutomator2Options options = new UiAutomator2Options();
        options.setPlatformName("Android");
        options.setCapability("automationName", "UiAutomator2");
        options.withBrowserName("Chrome");

        // Point manually to your ChromeDriver exe
        options.setChromedriverExecutable("C:\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");

        driver = new AndroidDriver(new URL("http://127.0.0.1:4723/"), options);

        System.out.println("Chrome setup before tests");
    }

    @Test
    public void openGoogle() throws InterruptedException {
        // Directly use driver.context if needed
        driver.context("CHROMIUM"); // no ContextAware import required

        driver.get("https://www.google.com");
        Thread.sleep(3000);
        System.out.println("Opened Google homepage in Chrome on Android");
    }
}