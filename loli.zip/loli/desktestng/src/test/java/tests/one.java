package tests;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class one {
	
	@Test(groups = {"group1","group2"})
	public  void feature1() {
		System.out.println("one");
	}
	
	@BeforeSuite
	public  void before() {
		System.out.println("before");
	}
	
	@BeforeClass
	public  void beforecalass() {
		System.out.println("before class");
	}
	
	@BeforeGroups("group1")
	public  void beforeg() {
		System.out.println("before group");
	}
	
	@BeforeGroups("group2")
	public  void beforeg2() {
		System.out.println("before group two");
	}
	
	@BeforeTest(groups = {"group1","group2"})
	public  void beforetest() {
		System.out.println("before test");
	}
	
	
}
