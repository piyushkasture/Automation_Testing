package tests;

import org.testng.annotations.*;

public class OnlyBeforeDemo {

    // 1️⃣ Runs once before the entire suite
    @BeforeSuite
    public void beforeSuite() {
        System.out.println(">> @BeforeSuite: Runs before the whole suite");
    }

    // 2️⃣ Runs before any <test> block in testng.xml
    @BeforeTest
    public void beforeTest() {
        System.out.println(">> @BeforeTest: Runs before <test> block");
    }

    // 3️⃣ Runs once before the first test method in this class
    @BeforeClass
    public void beforeClass() {
        System.out.println(">> @BeforeClass: Runs before first method in class");
    }

    // 4️⃣ Runs before each @Test method
    @BeforeMethod
    public void beforeMethod() {
        System.out.println(">> @BeforeMethod: Runs before each test method");
    }

    // --- Test cases ---
    @Test(groups = {"smoke"})
    public void loginTest() {
        System.out.println("Executing Login Test [Group: smoke]");
    }

    @Test(groups = {"regression"})
    public void addProductTest() {
        System.out.println("Executing Add Product Test [Group: regression]");
    }

    @Test(groups = {"smoke", "regression"})
    public void checkoutTest() {
        System.out.println("Executing Checkout Test [Groups: smoke, regression]");
    }

    @Test(groups = {"sanity"})
    public void searchTest() {
        System.out.println("Executing Search Test [Group: sanity]");
    }
}