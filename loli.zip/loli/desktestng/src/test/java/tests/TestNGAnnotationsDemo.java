package tests;

import org.testng.annotations.*;

public class TestNGAnnotationsDemo {

    // 1️⃣ Runs once before the entire test suite starts
    @BeforeSuite
    public void beforeSuite() {
        System.out.println(">> @BeforeSuite: Runs before the whole suite");
        // Example: Start server, initialize global resources
    }

    // 2️⃣ Runs before any <test> block in testng.xml
    @BeforeTest
    public void beforeTest() {
        System.out.println(">> @BeforeTest: Runs before <test> block");
        // Example: Setup test-level configurations
    }

    // 3️⃣ Runs once before the first test method in this class
    @BeforeClass
    public void beforeClass() {
        System.out.println(">> @BeforeClass: Runs before first method in class");
        // Example: Open DB connection, initialize WebDriver
    }

    // 4️⃣ Runs before each @Test method
    @BeforeMethod
    public void beforeMethod() {
        System.out.println(">> @BeforeMethod: Runs before each test method");
        // Example: Reset test data, login user
    }

    // 5️⃣ Actual test cases
    @Test
    public void testCaseOne() {
        System.out.println("Executing Test Case ONE");
    }

    @Test
    public void testCaseTwo() {
        System.out.println("Executing Test Case TWO");
    }

    // 6️⃣ Runs after each @Test method
    @AfterMethod
    public void afterMethod() {
        System.out.println(">> @AfterMethod: Runs after each test method");
        // Example: Logout user, clear cache
    }

    // 7️⃣ Runs once after all test methods in the class
    @AfterClass
    public void afterClass() {
        System.out.println(">> @AfterClass: Runs after all methods in class");
        // Example: Close DB connection, quit WebDriver
    }

    // 8️⃣ Runs after all tests in <test> block
    @AfterTest
    public void afterTest() {
        System.out.println(">> @AfterTest: Runs after <test> block");
        // Example: Generate test report
    }

    // 9️⃣ Runs once after the entire suite finishes
    @AfterSuite
    public void afterSuite() {
        System.out.println(">> @AfterSuite: Runs after the whole suite");
        // Example: Stop server, release global resources
    }
}