package com.filehandling;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class hh {

	public static void main(String[] args) throws FileNotFoundException {

		String filePath = "text";

		// Method 1: Read byte by byte
		System.out.println("   Reading byte by byte:");

		try (FileInputStream fis = new FileInputStream(filePath)) {
			int byteData;
			int count = 0;
			List<Character> list = new ArrayList<>();

			while ((byteData = fis.read()) != -1) {
//                    System.out.println(byteData + " (" + (char) byteData + ")");
				count++;
				list.add((char) byteData);
			}
			for (Character c : list) {
				System.out.print(c);
			}

			System.out.println("Total characters read: " + count);
			for (Character character : list) {

				int co = 0;
				for (Character character2 : list) {

					if (character.equals(character2)) {
						co++;
					}
				}
				System.out.println(character + ":" + co);

			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}