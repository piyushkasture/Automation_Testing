package lock;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.*;

public class User {
    // private fields
    private String username;
    private String password;

    // Constructor
    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    // Getters
    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    // Read login data from Excel
    public static List<User> readLogin(String path) throws IOException {
        List<User> users = new ArrayList<>();

        try (FileInputStream fis = new FileInputStream(path);
             Workbook workbook = WorkbookFactory.create(fis)) {

            Sheet sheet = workbook.getSheet("Sheet1"); // or workbook.getSheetAt(0)
            int lastRow = sheet.getLastRowNum();

            for (int r = 1; r <= lastRow; r++) { // start at row 1 (skip header)
                Row row = sheet.getRow(r);
                if (row == null) continue;

                Cell userCell = row.getCell(0, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                Cell passCell = row.getCell(1, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);

                String username = getCellValueAsString(userCell);
                String password = getCellValueAsString(passCell);

                users.add(new User(username, password));
            }
        }
        return users;
    }

    // Helper to convert cell values to String
    private static String getCellValueAsString(Cell cell) {
        if (cell == null) return "";

        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getDateCellValue().toString();
                } else {
                    return String.valueOf(cell.getNumericCellValue());
                }
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case FORMULA:
                return cell.getCellFormula();
            case BLANK:
                return "";
            default:
                return "";
        }
    }

    // Main method
    public static void main(String[] args) throws IOException {
        String path = "login.xlsx"; // Excel file must exist in project root
        List<User> users = readLogin(path);

        System.out.println("Total users: " + users.size());
        for (User user : users) {
            System.out.println("Username: " + user.getUsername() + ", Password: " + user.getPassword());
        }
    }
}