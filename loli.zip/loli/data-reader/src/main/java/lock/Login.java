package lock;

import java.util.ArrayList;
import java.util.List;

public class Login {
    public static void main(String[] args) {
        List<User> users = new ArrayList<>();
        users.add(new User("alice", "12345"));
        users.add(new User("bob", "qwerty"));
        users.add(new User("charlie", "pass123"));

        System.out.println("Total users: " + users.size());
        for (User us : users) {
            System.out.println("Username: " + us.username + ", Password: " + us.password);
        }
    }
}

class User {
    public String username;
    public String password;

    public User(String u, String p) {
        this.username = u;
        this.password = p;
    }
}