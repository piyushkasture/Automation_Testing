package base;

public class BasePage {
	
	public BasePage() {
		System.out.println("Base page constructor");
	}
	
	public String getPageTitle() {
//		return driver.getTitle();
		return "Page Title";
	}
	
}
