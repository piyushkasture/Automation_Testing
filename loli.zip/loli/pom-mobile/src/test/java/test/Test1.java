package test;

import java.sql.Driver;

import org.testng.Assert;
import org.testng.annotations.Test;

import pagelogin.LoginPage;
import pagelogin.LoginPageAndroid;
import pagelogin.LoginPageIOS;

public class Test1 {

	@Test(enabled = false)
	public void webLoginMethod() {

	}
	
	@Test
	public void mobileLoginMethod() {
		System.out.println("Mobile login method");
	}
	
//	@Test(enabled = false)
//	public void testMethod1() {
//		
////		driver.findElement(By.id("userid")).sendKeys("test@com");
////		driver.findElement(By.id("userid")).sendKeys("test@com");
////		driver.findElement(By.id("userid")).sendKeys("test@com");
//		
////		System.out.println("Test 1- Method 1");
//		
//		LoginPage loginPage = new LoginPage();
//		Assert.assertEquals(loginPage.getPageTitle(), "Page Title");
//		
//		loginPage.enterUsername("test@com");
//		loginPage.enterPassword("abc123");
//		loginPage.clickLoginButton();
//	}
	
	@Test
	public void loginWithAndroidAndIOS() {
		
		LoginPage loginPage = null;
		
		if(System.getProperty("platform").equals("android")) {
			loginPage = new LoginPageAndroid();
		} else if(System.getProperty("platform").equals("ios")) {
			loginPage = new LoginPageIOS();
		}
		loginPage.enterUsername("test@com");
		loginPage.enterPassword("abc123");
		loginPage.clickLoginButton();
	}

}
