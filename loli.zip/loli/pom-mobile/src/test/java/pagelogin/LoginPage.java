package pagelogin;

import base.BasePage;

public abstract class LoginPage extends BasePage {
//	WebElement username, password, loginButton;
	public void login() {
		System.out.println("Login page contructor");
		initElements();
	}
	
	
	private void initElements() {
//		this.username = driver.findElement(By.id("userid"));
//		this.password = driver.findElement(By.id("password"));
//		this.loginButton = driver.findElement(By.id("loginBtn"));
		// TODO Auto-generated method stub
		
	}

	public void enterUsername(String username) {
		System.out.println("Enter username: " + username);	
		
	}
	public void enterPassword(String password) {
		System.out.println("Enter password: " + password);
	}
	public abstract void clickLoginButton();
	

}
