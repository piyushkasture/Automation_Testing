package pagelogin;

public class LoginPageAndroid extends LoginPage {

	public LoginPageAndroid() {
		System.out.println("Login with Android Contructor");
	}

	@Override
	public void clickLoginButton() {
		System.out.println("Click on android login");
		// TODO Auto-generated method stub
		
	} 
	
}

