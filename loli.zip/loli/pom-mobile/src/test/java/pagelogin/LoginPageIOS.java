package pagelogin;

public class LoginPageIOS extends LoginPage {
	
	public LoginPageIOS() {
		System.out.println("IOS Login page Contructor");
		// TODO Auto-generated constructor stub
	}
		


	@Override
	public void clickLoginButton() {
		System.out.println("Click with IOS login page");
		// TODO Auto-generated method stub
		
	}

}
