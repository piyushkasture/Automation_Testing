package dataprovider;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DPClass {
	

	@DataProvider(name = "dp2",parallel = false)  /// excute one by one if false
	public String[] getData() {
		return new String[] { "madam", "sir", "abc", "racecar" };
	}

	@Test(dataProvider = "dp2")
	private void ptr(String a) throws InterruptedException {
		System.out.println(a);
		Thread.sleep(3000);
	}
}
