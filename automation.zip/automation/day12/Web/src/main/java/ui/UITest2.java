package ui;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class UITest2 {

	@Test
	public void m1() {
		System.out.println("UITest2 Method m1");
	}
	
	@Test
	public void m2() {
		System.out.println("UITest2 Method m2");
	}
	

	@BeforeSuite
	public void bs1() {
		System.out.println("UITest2 BS1");
	}
	
	@AfterSuite
	public void as1() {
		System.out.println("UITest2 AS1");
	}
//	
	@AfterTest
	public void at1() {
		System.out.println("UITest1 AT1");
	}
}
