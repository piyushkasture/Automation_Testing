package test;

import org.testng.annotations.Test;

public class ALab4_ExpectedExceptions {

	@Test
	public void m2() {
		System.out.println("Method m2");
	}
	
	//  it check specific type exception 
	// if you write other exception that you doesnt want then it give error or fail test casess 
	@Test(expectedExceptions = {NullPointerException.class, ArrayIndexOutOfBoundsException.class})
	public void m1() {
		System.out.println("Method m1");
		String str = null; //  normally it check negative testing i.e expected exception arriving or not 
		str.length();
	}
	
	@Test
	public void m3() {
		System.out.println("Method m3");
	}
	
}
